import os
import requests
import google.generativeai as genai
import json
from tqdm import tqdm
from config import GEMINI_API_KEY, generation_config, safety_settings
from typing import List, Dict, Any


os.environ['http_proxy'] = "http://10.16.1xx.6:xxxx"
os.environ['https_proxy'] = "http://10.16.1xx.6:xxxx"


proxies = {
    "http": "http://10.16.1xx.6:xxxx",
    "https": "http://10.16.1xx.6:xxxx"
}


genai.configure(api_key=GEMINI_API_KEY, transport='rest')


session = requests.Session()
session.proxies.update(proxies)


Documents = List[str]
Embeddings = List[List[float]]

def list_available_models():
    models = genai.list_models()
    print("Available models:")
    for model in models:
        print(model)

if __name__ == "__main__":
    list_available_models()


class GeminiEmbeddingFunction:
    def __call__(self, input: List[str]) -> List[List[float]]:
        return self.embed_documents(input)

    def embed_documents(self, documents: List[str]) -> List[List[float]]:
        model = 'models/text-embedding-004'
        response = genai.embed_content(
            model=model,
            content=documents
        )

        print("Response from embed_content:", response)

        if "embedding" in response:
            embeddings = response["embedding"]
            return embeddings
        else:
            raise KeyError("Key 'embedding' not found in the response")

    def embed_query(self, query: List[str]) -> List[List[float]]:
        return self.embed_documents(query)



def convert_json_to_text(feature_vector: Dict[str, Any]) -> str:
    print(f"Debug: Feature vector before conversion: {feature_vector} (type: {type(feature_vector)})")
    text_representation = []
    if "name" in feature_vector:
        text_representation.append(f"Contract Name: {feature_vector['name']}")
    if "func_calls" in feature_vector:
        text_representation.append(f"Function Calls: {', '.join(feature_vector['func_calls'])}")
    if "func_def" in feature_vector:
        func_def = feature_vector['func_def']
        if isinstance(func_def, list):
            func_def = ', '.join(func_def)
        text_representation.append(f"Function Definition: {func_def}")
    if "safe_func_call_info" in feature_vector:
        for info in feature_vector["safe_func_call_info"]:
            if isinstance(info, dict):
                text_representation.append(f"Safe Function Call - Location: {info.get('location', {}).get('src', 'N/A')}, "
                                           f"Name: {info.get('location', {}).get('name', 'N/A')}, "
                                           f"Modifications: {', '.join(info.get('modification', []))}")
            else:
                print(f"Unexpected data format in 'safe_func_call_info': {info}")
    if "state_vars" in feature_vector:
        text_representation.append(f"State Variables: {', '.join(feature_vector['state_vars'])}")

    print(f"Debug: Text representation: {text_representation}")
    return "\n".join(text_representation)


def embed_contract_source(contract_path: str, output_dir: str) -> str:

    embedding_function = GeminiEmbeddingFunction()

    with open(contract_path, 'r', encoding='utf-8') as f:
        source_code = f.read()

    source_embedding = embedding_function([source_code])[0]

    contract_name = os.path.basename(contract_path).replace('.sol', '')
    output_path = os.path.join(output_dir, f"{contract_name}_source_embedding.json")


    os.makedirs(output_dir, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump({"embedding": source_embedding}, f)

    # 添加调试信息
    print(f"源代码嵌入向量已保存到: {output_path}")

    return output_path



def store_feature_vectors(feature_dir, output_dir, vulnerability_type, batch_size=10):
    if not os.path.exists(feature_dir):
        print(f"Directory not found: {feature_dir}")
        return

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    feature_files = [os.path.join(feature_dir, f) for f in os.listdir(feature_dir) if f.endswith('.json')]

    embedding_function = GeminiEmbeddingFunction()

    for feature_file in tqdm(feature_files, desc=f"Processing {vulnerability_type}"):
        print(f"Processing feature file: {feature_file}")
        with open(feature_file, 'r', encoding='utf-8') as f:
            feature_vectors = json.load(f)

        text_representations = [convert_json_to_text(contract) for contract in feature_vectors if
                                isinstance(contract, dict)]
        embeddings = embedding_function(text_representations)

        if embeddings and len(embeddings) == len(text_representations):
            for i, embedding in enumerate(embeddings):
                file_name = os.path.basename(feature_file).replace('.json', f'_{i}.json')
                file_path = os.path.join(output_dir, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump({"embedding": embedding}, f)
                print(f"Saved {file_name}")
        else:
            print(f"Mismatch in embeddings and text representations count for file: {feature_file}")
            print(
                f"Embeddings count: {len(embeddings) if embeddings else 'None'}, Text representations count: {len(text_representations)}")
            print(f"Embeddings: {embeddings}")
            print(f"Text representations: {text_representations}")

class KnowledgeRetrieval:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        if not os.path.exists(self.data_dir) or not os.listdir(self.data_dir):
            raise ValueError("specified dataset is empty")

    def retrieve_knowledge(self, feature_vector: Dict[str, Any]):
        if 'embedding' not in feature_vector:
            raise ValueError("The provided feature vector does not contain an embedding.")
        best_match = None
        best_similarity = float('-inf')
        best_file_name = None

        for file_name in os.listdir(self.data_dir):
            file_path = os.path.join(self.data_dir, file_name)
            with open(file_path, 'r', encoding='utf-8') as f:
                stored_data = json.load(f)
                if 'embedding' not in stored_data:
                    continue
                stored_embedding = stored_data['embedding']
                similarity = self.cosine_similarity(self.convert_to_float_list(feature_vector['embedding']), self.convert_to_float_list(stored_embedding))
                print(f"Comparing with {file_name}: similarity = {similarity}")
                if similarity > best_similarity:
                    best_similarity = similarity
                    best_match = stored_embedding
                    best_file_name = file_name


        if best_match is None:
            print(f"No matching context found for feature vector: {feature_vector}")
        else:
            print(f"Best match is {best_file_name} with similarity: {best_similarity}")

        return best_match, best_file_name

    @staticmethod
    def convert_to_float_list(vector):
        return [float(x) for x in vector]

    @staticmethod
    def cosine_similarity(vec1, vec2):
        dot_product = sum(p * q for p, q in zip(vec1, vec2))
        magnitude1 = sum(p ** 2 for p in vec1) ** 0.5
        magnitude2 = sum(q ** 2 for q in vec2) ** 0.5
        if not magnitude1 or not magnitude2:
            return 0
        return dot_product / (magnitude1 * magnitude2)

def askGeMiNi(feature_embedding: List[float], source_embedding: List[float], vulnerability_type: str) -> str:
    prompt = (
        f"根据以下嵌入向量，检测智能合约中的漏洞。请逐步推理并提供详细的检测结果：\n"
        f"特征向量：{feature_embedding}\n"
        f"合约源代码向量：{source_embedding}\n"
        f"检测到的漏洞类型：{vulnerability_type}\n"
        f"请检查以下漏洞类型：\n"
        f"1. ERC721 Reentrancy\n"
        f"2. Public Burn\n"
        f"3. Resiky Mutable Proxy\n"
    )

    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)

    generated_text = response.candidates[0].content.parts[0].text
    return generated_text

if __name__ == "__main__":
    output_dir = './vectorDB'
    feature_dir = './Feature_Extractor/feature'
    store_feature_vectors(feature_dir, output_dir, "Vulnerability")

    retriever = KnowledgeRetrieval(output_dir)

    feature_files = [os.path.join(feature_dir, f) for f in os.listdir(feature_dir) if f.endswith('.json')]

    for feature_file in feature_files:
        with open(feature_file, 'r', encoding='utf-8') as f:
            feature_vectors = json.load(f)

        embedding_function = GeminiEmbeddingFunction()
        embeddings = embedding_function([convert_json_to_text(fv) for fv in feature_vectors])

        for fv, embedding in zip(feature_vectors, embeddings):
            fv['embedding'] = embedding
            context, best_file_name = retriever.retrieve_knowledge(fv)
            if best_file_name:
                vulnerability_type = best_file_name.split('_')[0]
                print(f"File: {os.path.basename(feature_file)}, Context: {context}, Detected Vulnerability: {vulnerability_type}")
