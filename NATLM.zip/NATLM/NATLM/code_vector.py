import os
import json
from knowledge_vector import GeminiEmbeddingFunction

# 设置代理
os.environ['http_proxy'] = "http://10.16.1xx.6:xxxx"
os.environ['https_proxy'] = "http://10.16.1xx.6:xxxx"

# 设置代理
proxies = {
    "http": "http://10.16.1xx.6:xxxx",
    "https": "http://10.16.1xx.6:xxxx"
}

# 设置 OpenAI API 密钥
genai.configure(api_key=GEMINI_API_KEY, transport='rest')

# 创建会话并配置代理
session = requests.Session()
session.proxies.update(proxies)

def embed_contract_source(contract_path: str, embedding_function: GeminiEmbeddingFunction, output_dir: str) -> str:
    """
    嵌入智能合约源代码并保存嵌入向量到文件
    """
    with open(contract_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    source_embedding = embedding_function([source_code])[0]

    # 保存嵌入向量到文件
    source_embedding_path = os.path.join(output_dir,
                                         os.path.basename(contract_path).replace('.sol', '_source_embedding.json'))
    with open(source_embedding_path, 'w', encoding='utf-8') as f:
        json.dump({"embedding": source_embedding}, f)

    return source_embedding_path


if __name__ == "__main__":
    contract_dir = './data/NFTcontracts/test'
    output_dir = './vector'

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    embedding_function = GeminiEmbeddingFunction()
    contract_files = [os.path.join(contract_dir, f) for f in os.listdir(contract_dir) if f.endswith('.sol')]

    for contract_file in contract_files:
        print(f"Processing contract file: {contract_file}")
        embed_contract_source(contract_file, embedding_function, output_dir)
