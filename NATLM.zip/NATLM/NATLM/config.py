from google.ai.generativelanguage_v1beta.types import content

# GeMiNi
GEMINI_API_KEY = 'AIzxxxxxxxxx'

# Create the model
generation_config = {
  "temperature": 0.4,
  "top_p": 0.9,
  "top_k": 64,
  "max_output_tokens": 2048,
  "response_schema": content.Schema(
    type=content.Type.OBJECT,
    description="Return the defect types of the NFT smart contract",
    properties={
      'defect': content.Schema(
        type=content.Type.ARRAY,
        items=content.Schema(
          type=content.Type.OBJECT,
          properties={
            'name': content.Schema(
              type=content.Type.STRING,
              description="name of the NFT",
            ),
          },
        ),
      ),
    },
  ),
   "response_mime_type": "application/json",
}
safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    }
]
