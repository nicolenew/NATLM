import os
import requests
import google.generativeai as genai
import json
from tqdm import tqdm
from config import GEMINI_API_KEY
from typing import List, Dict, Any

os.environ['http_proxy'] = "http://10.16.1xx.6:xxxx"
os.environ['https_proxy'] = "http://10.16.1xx.6:xxxx"

proxies = {
    "http": "http://10.16.1xx.6:xxxx",
    "https": "http://10.16.1xx.6:xxxx"
}


genai.configure(api_key=GEMINI_API_KEY, transport='rest')

# 创建会话并配置代理
session = requests.Session()
session.proxies.update(proxies)

# 定义类型别名
Documents = List[str]
Embeddings = List[List[float]]

# 嵌入生成器类
class GeminiEmbeddingFunction:
    def __call__(self, input: Documents) -> Embeddings:
        return self.embed_documents(input)

    def embed_documents(self, documents: Documents) -> Embeddings:
        model = 'models/text-embedding-004'
        title = "defect types of the NFT smart contract"
        response = genai.embed_content(
            model=model,
            content=documents,
            task_type="retrieval_document",
            title=title
        )
        # 添加调试信息
        print("Response from embed_content:", response)

        if "embedding" in response:
            embeddings = response["embedding"]
            return embeddings
        else:
            raise KeyError("Key 'embedding' not found in the response")


def convert_json_to_text(feature_vector):
    text_representation = []
    if "name" in feature_vector:
        text_representation.append(f"Contract Name: {feature_vector['name']}")
    if "code" in feature_vector:
        text_representation.append(f"Contract Code: {feature_vector['code']}")
    return "\n".join(text_representation)


def store_feature_vectors(json_path, output_dir, vulnerability_type, batch_size=10):
    if not os.path.exists(json_path):
        print(f"File not found: {json_path}")
        return

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    feature_vectors = data.get("contracts", [])
    print(f"Total feature vectors for {vulnerability_type}: {len(feature_vectors)}")

    batches = [feature_vectors[i:i + batch_size] for i in range(0, len(feature_vectors), batch_size)]

    embedding_function = GeminiEmbeddingFunction()

    for batch in tqdm(batches, desc=f"Processing {vulnerability_type}"):

        text_representations = [convert_json_to_text(contract) for contract in batch if isinstance(contract, dict)]
        embeddings = embedding_function(text_representations)
        if embeddings and len(embeddings) == len(text_representations):
            for i, embedding in enumerate(embeddings):
                file_path = os.path.join(output_dir, f"{vulnerability_type}_{i}.json")
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump({"embedding": embedding}, f)
                print(f"Saved {vulnerability_type}_{i}.json")  # 添加调试信息
        else:
            print(f"Mismatch in embeddings and text representations count for batch in {vulnerability_type}")
            print(
                f"Embeddings count: {len(embeddings) if embeddings else 'None'}, Text representations count: {len(text_representations)}")
            print(f"Embeddings: {embeddings}")
            print(f"Text representations: {text_representations}")

if __name__ == "__main__":

    output_dir = './know_content_vectorDB'
    store_feature_vectors('./data/learning_samples/ERC721Reentrancy.json', output_dir, "ERC721Reentrancy")
    store_feature_vectors('./data/learning_samples/PublicBurn.json', output_dir, "PublicBurn")
    store_feature_vectors('./data/learning_samples/RiskyMutableProxy.json', output_dir, "RiskyMutableProxy")

