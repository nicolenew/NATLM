import os
import re
import json
import requests
import google.generativeai as genai
from tqdm import tqdm
from glob import glob
from config import GEMINI_API_KEY, generation_config, safety_settings
from data.ast_parser import ContractParser
from Feature_Extractor.feature import FeatureExtractor
from knowledge_vector import GeminiEmbeddingFunction, KnowledgeRetrieval, convert_json_to_text, askGeMiNi, embed_contract_source

# 设置代理
os.environ['http_proxy'] = "http://10.16.1xx.6:xxxx"
os.environ['https_proxy'] = "http://10.16.1xx.6:xxxx"

# 设置 OpenAI API 密钥
genai.configure(api_key=GEMINI_API_KEY, transport='rest')

# 定义路径
AST_DIR = './data/AST_info/'
FEATURES_DIR = './Feature_Extractor/feature/'
VECTOR_PATH = './vector'
VECTOR_DB_PATH = './vectorDB'

def process_contract(contract_path: str):
    """
    处理智能合约：生成AST，提取特征，生成嵌入向量，并与知识库进行比较。
    """

    if not os.path.exists(AST_DIR):
        os.makedirs(AST_DIR)
    if not os.path.exists(FEATURES_DIR):
        os.makedirs(FEATURES_DIR)


    parser = ContractParser(contract_path, ['./node_modules/@openzeppelin/contracts/'], "solidity")
    contract_details = parser.extract_contract_ast(contract_path)

    file_name = os.path.basename(contract_path).replace('.sol', '')
    ast_file_path = os.path.join(AST_DIR, f'{file_name}.json')
    with open(ast_file_path, 'w', encoding='utf-8') as f:
        json.dump(contract_details, f, indent=4)


    extractor = FeatureExtractor(AST_DIR)
    features = extractor.extract_features()
    print(f"特征提取成功：{features}")

    feature_file_path = os.path.join(FEATURES_DIR, f"{file_name}_features.json")
    with open(feature_file_path, 'w', encoding='utf-8') as f:
        json.dump(features, f, indent=4)


    embedding_function = GeminiEmbeddingFunction()
    feature_vectors = []

    for feature in features:
        text_representation = convert_json_to_text(feature)
        embedding = embedding_function([text_representation])
        feature_vector = {
            "embedding": embedding[0],
            "has_safe_func_call": feature.get("safe_func_call_info"),
            "burn_calls": feature.get("func_calls", []),
            "state_vars": feature.get("state_vars", []),
            "file_name": feature.get("file_name")
        }
        feature_vectors.append(feature_vector)
    print(f"嵌入向量生成成功!")

    if not os.path.exists(VECTOR_PATH):
        os.makedirs(VECTOR_PATH)
    vector_file_path = os.path.join(VECTOR_PATH, f'{file_name}_feature_vector.json')
    with open(vector_file_path, 'w', encoding='utf-8') as f:
        json.dump(feature_vectors, f, separators=(', ', ': '))


    source_embedding_path = embed_contract_source(contract_path, VECTOR_PATH)


    print(f"生成的源代码嵌入向量路径: {source_embedding_path}")

    return feature_vectors, source_embedding_path

def detect_vulnerabilities_with_embeddings(vector_dir, contract_dir):
    """
    使用生成的嵌入向量与vectorDB中的漏洞嵌入向量进行比较。
    """
    retriever = KnowledgeRetrieval(VECTOR_DB_PATH)
    detections = []
    vulnerability_types = ["ERC721 Reentrancy", "Public Burn", "Resiky Mutable Proxy"]
    vector_files = [os.path.join(vector_dir, f) for f in os.listdir(vector_dir) if f.endswith('.json')]

    for vector_file in vector_files:
        with open(vector_file, 'r', encoding='utf-8') as f:
            feature_vectors = json.load(f)

        for feature_vector in feature_vectors:
            if not isinstance(feature_vector, dict):
                continue

            best_vulnerability_type = None
            best_similarity = float('-inf')
            matched_file_name = None

            for vulnerability_type in vulnerability_types:
                print(f"正在检测漏洞类型：{vulnerability_type}")

                for db_file in os.listdir(VECTOR_DB_PATH):
                    if vulnerability_type.replace(" ", "").lower() in db_file.lower():
                        file_path = os.path.join(VECTOR_DB_PATH, db_file)
                        with open(file_path, 'r', encoding='utf-8') as f:
                            stored_data = json.load(f)
                            if 'embedding' not in stored_data:
                                continue
                            stored_embedding = stored_data['embedding']
                            similarity = retriever.cosine_similarity(feature_vector['embedding'], stored_embedding)
                            print(f"Comparing with {db_file} for {vulnerability_type}: similarity = {similarity}")
                            if similarity > best_similarity:
                                best_similarity = similarity
                                best_vulnerability_type = vulnerability_type
                                matched_file_name = re.sub(r'_\d+', '', db_file)

            print(f"检测到的漏洞类型: {best_vulnerability_type}, 匹配文件名: {matched_file_name}")


            contract_file_name = os.path.basename(vector_file).replace('_feature_vector.json', '')
            source_embedding_file = os.path.join(vector_dir, f'{contract_file_name}_source_embedding.json')
            print(f"源代码嵌入向量路径: {source_embedding_file}")

            with open(source_embedding_file, 'r', encoding='utf-8') as f:
                source_embedding = json.load(f)["embedding"]

            if best_vulnerability_type: 
                detection = askGeMiNi(feature_vector['embedding'], source_embedding, best_vulnerability_type)
                detections.append({
                    "vulnerability_type": best_vulnerability_type,
                    "detection": detection,
                    "file_name": feature_vector.get("file_name")
                })

    return detections

def generate_audit_report(detections: list, output_path: str):
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    report_txt_path = os.path.join(output_path, 'audit_report.txt')
    with open(report_txt_path, 'w', encoding='utf-8') as f:
        for detection in detections:
            f.write(f"漏洞类型: {detection['vulnerability_type']}\n")
            f.write(f"检测结果: {detection['detection']}\n\n")

    print(f"审计报告已生成: {report_txt_path}")

def process_multiple_contracts(directory_path: str, output_path: str):
    """
    处理指定文件夹中的多个智能合约文件。
    """
    contract_files = glob(os.path.join(directory_path, "*.sol"))
    all_detections = []

    for contract_file in contract_files:
        print(f"正在处理合约文件：{contract_file}")
        feature_vectors, source_embedding_path = process_contract(contract_file)

    detections = detect_vulnerabilities_with_embeddings(VECTOR_PATH, directory_path)
    all_detections.extend(detections)

    generate_audit_report(all_detections, output_path)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="智能合约漏洞检测工具")
    parser.add_argument('--contract', type=str, help="单个智能合约文件路径")
    parser.add_argument('--directory', type=str, help="包含多个智能合约文件的文件夹路径")
    parser.add_argument('--output', type=str, default='./audit_report', help="审计报告输出文件夹路径")

    args = parser.parse_args()

    if args.contract:
        process_multiple_contracts(os.path.dirname(args.contract), args.output)
    elif args.directory:
        process_multiple_contracts(args.directory, args.output)
    else:
        print("请提供单个合约文件路径或包含多个合约文件的文件夹路径。")
