def find_referenced_declaration_values(node):
    referenced_declarations = []

    def recurse(current_node):
        if isinstance(current_node, dict):
            if "name" in current_node:
                referenced_declarations.append(current_node["name"])
            for value in current_node.values():
                recurse(value)
        elif isinstance(current_node, list):
            for item in current_node:
                recurse(item)

    recurse(node)
    return referenced_declarations

class SafeFunWalker:
    def __init__(self):
        self.found_function_call = False  # 标记是否找到函数调用
        self.call_loc = ""  # 存储函数调用的位置
        self.modifications_after_call = []  # 存储函数调用后的修改
        self.safe_mint_calls = []  # 存储_safeMint调用及其后的变量修改情况
        self.safe_transfer_calls = []  # 存储safeTransferFrom调用及其后的变量修改情况

    def walk(self, node, attributes, nodes):
        if isinstance(attributes, dict):
            self._walk_with_attrs(node, attributes, nodes)  # 如果属性是字典，调用带属性的遍历函数

    def _walk_with_attrs(self, node, attributes, nodes):
        if self._check_attributes(node, attributes):
            nodes.append(node)  # 如果节点符合属性条件，将其加入节点列表
        else:
            if isinstance(node, dict):
                for key in node:
                    if isinstance(node[key], list):
                        for child in node[key]:
                            self._walk_with_attrs(child, attributes, nodes)  # 递归遍历字典中的列表
                    elif isinstance(node[key], dict):
                        self._walk_with_attrs(node[key], attributes, nodes)  # 递归遍历字典中的字典
                    else:
                        continue
            elif isinstance(node, list):
                for key in node:
                    self._walk_with_attrs(node[key], attributes, nodes)  # 递归遍历列表

    def walk_safe_fun(self, node):
        nodes = []
        found_function_call = False  # 标记是否找到函数调用
        call_loc = []
        modifications_after_call = []
        self.walk(node, {"nodeType": "FunctionDefinition"}, nodes)  # 遍历AST，查找函数定义节点
        for i in range(len(nodes)):
            if "body" in nodes[i].keys():
                if "statements" in nodes[i]["body"].keys():
                    for statement in nodes[i]["body"]["statements"]:
                        if found_function_call:
                            if (
                                statement.get("nodeType") == "ExpressionStatement"
                                and statement.get("expression", {}).get("nodeType")
                                == "Assignment"
                            ):
                                modification = {
                                    "location": call_loc[0],
                                    "modification": find_referenced_declaration_values(statement)
                                }
                                modifications_after_call.append(modification)
                                if call_loc[0].get("name") == "_safeMint":
                                    self.safe_mint_calls.append(modification)
                                elif call_loc[0].get("name") == "safeTransferFrom":
                                    self.safe_transfer_calls.append(modification)
                        else:
                            node_safe_mint = []
                            node_safe_transfer = []
                            self.walk(statement, {"name": "_safeMint"}, node_safe_mint)
                            self.walk(statement, {"name": "safeTransferFrom"}, node_safe_transfer)
                            if len(node_safe_mint):
                                found_function_call = True  # 如果找到_safeMint调用，标记为找到函数调用
                                for node in node_safe_mint:
                                    call_loc.append({"src": node["src"], "name": "_safeMint"})  # 记录_safeMint调用的位置
                            if len(node_safe_transfer):
                                found_function_call = True  # 如果找到safeTransferFrom调用，标记为找到函数调用
                                for node in node_safe_transfer:
                                    call_loc.append({"src": node["src"], "name": "safeTransferFrom"})  # 记录safeTransferFrom调用的位置
                            continue

                    if len(modifications_after_call) != 0:
                        self.modifications_after_call.extend(modifications_after_call)  # 如果找到修改，更新修改列表
                    call_loc = []
                    found_function_call = False

    def _check_attributes(self, node, attributes):
        if not isinstance(node, dict):
            return False
        for name in attributes:
            if isinstance(attributes[name], str):
                if name not in node or attributes[name] != node[name]:
                    return False
            elif name not in node or node[name] != attributes[name]:
                return False
        return True  # 检查节点是否符合属性条件

    def _check_list_of_attributes(self, node, list_of_attributes):
        for attrs in list_of_attributes:
            if self._check_attributes(node, attrs):
                return True
        return False  # 检查节点是否符合属性列表中的任意一个条件
