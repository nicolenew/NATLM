import os.path
import re
import json
import subprocess
import multiprocessing as mp
import pandas as pd
from solcx import compile_source, install_solc, get_solc_version, set_solc_version
from tqdm import tqdm
from loguru import logger
from typing import AnyStr
from data.ast_walker import AstWalker
from data.safe_func_walker import SafeFunWalker
import shlex

join = os.path.join
install_solc('0.8.16')
set_solc_version('0.8.16')

class ContractParser:

    method_to_ref_decl_ids = {}

    def __init__(self, filename, remap, input_type):
        self.input_type = input_type
        self.remap = remap
        self.filename = filename
        if input_type == "solidity":
            self.source_list = self.get_source_list(filename)
            self.storage_layouts = self.get_storage_layouts(filename)
        else:
            raise Exception("There is no such type of inputter")
        self.contracts = self.extract_contract_definitions(self.source_list)

    def get_source_list(self, filename):
        cmd = "solc --base-path . --include-path {} --combined-json ast {}".format(
            ":".join(self.remap),
            filename
        )
        out, err = run_command(cmd)

        # Save the raw JSON string to a file for inspection
        with open("compiler_output.json", "w") as f:
            f.write(out)
        try:
            out = json.loads(out)
            logger.info(f"Parsed JSON output successfully: {out.keys()}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON: {str(e)}")
            logger.error(f"Output was: {out}")
            if err:
                logger.error(f"Compiler error output: {err}")
            raise
        if "sources" not in out:
            logger.error(f"Missing 'sources' in output: {out}")
            if err:
                logger.error(f"Compiler error output: {err}")
            raise KeyError("Missing 'sources' in output")
        return out["sources"]

    def get_storage_layouts(self, filename):
        cmd = "solc --base-path . --include-path {} --combined-json storage-layout {}".format(
            ":".join(self.remap),
            filename
        )
        out, err = run_command(cmd)
        try:
            out = json.loads(out)
            logger.info(f"Parsed JSON output successfully: {out.keys()}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON: {str(e)}")
            logger.error(f"Output was: {out}")
            if err:
                logger.error(f"Compiler error output: {err}")
            raise
        if "contracts" not in out:
            logger.error(f"Missing 'contracts' in output: {out}")
            if err:
                logger.error(f"Compiler error output: {err}")
            raise KeyError("Missing 'contracts' in output")
        return out["contracts"]

    def save_storage_layouts(self, output_file):
        with open(output_file, 'w') as f:
            json.dump(self.storage_layouts, f, indent=4)
        logger.info(f"Storage layouts saved to {output_file}")

    def extract_contract_definitions(self, sourcesList):
        ret = {"contractsById": {}, "contractsByName": {}, "sourcesByContract": {}}
        walker = AstWalker()
        for k in sourcesList:
            ast_key = "ast" if "ast" in sourcesList[k] else "AST" if "AST" in sourcesList[k] else None
            if not ast_key:
                logger.error(f"Missing 'ast' or 'AST' in sourcesList for key {k}: {sourcesList[k]}")
                raise KeyError(f"Missing 'ast' in sourcesList for key {k}")
            ast = sourcesList[k][ast_key]
            nodes = []
            walker.walk(ast, {"nodeType": "ContractDefinition"}, nodes)
            for node in nodes:
                ret["contractsById"][node["id"]] = node
                ret["sourcesByContract"][node["id"]] = k
                ret["contractsByName"][k + ":" + node["name"]] = node
        return ret

    def get_linearized_base_contracts(self, node):
        return map(
            lambda id: self.contracts["contractsById"][id], node["linearizedBaseContracts"]
        )

    def extract_state_definitions(self, node):
        state_vars = []
        if node:
            base_contracts = self.get_linearized_base_contracts(node)
            for contract in base_contracts:
                if "nodes" in contract:
                    for item in contract["nodes"]:
                        if item["nodeType"] == "VariableDeclaration":
                            state_vars.append(item)
        return state_vars

    def extract_states_definitions(self):
        ret = {}
        for contract in self.contracts["contractsById"]:
            name = self.contracts["contractsById"][contract]["name"]
            source = self.contracts["sourcesByContract"][contract]
            full_name = source + ":" + name
            ret[full_name] = self.extract_state_definitions(self.contracts["contractsById"][contract])
        return ret


    def extract_states_storage_layouts(self):
        ret = {}
        for contract in self.contracts["contractsById"]:
            name = self.contracts["contractsById"][contract]["name"]
            source = self.contracts["sourcesByContract"][contract]
            full_name = source + ":" + name
            ret[full_name] = self.extract_state_storage_layouts(full_name)
        return ret

    def extract_state_storage_layouts(self, c_name):
        node = self.storage_layouts[c_name]["storage-layout"]["storage"]
        id_to_state_vars = {}
        if node:
            for i in node:
                id_to_state_vars[i["astId"]] = i["slot"]
        return id_to_state_vars

    def extract_func_call_definitions(self, node):
        walker = AstWalker()
        nodes = []
        if node:
            walker.walk(node, {"nodeType": "FunctionCall"}, nodes)
        return nodes

    def extract_func_definitions(self, node):
        walker = AstWalker()
        nodes = []
        if node:
            walker.walk(node, {"nodeType": "FunctionDefinition"}, nodes)

        return nodes

    def extract_safe_func_call_info(self, c_name):
        node = self.contracts["contractsByName"][c_name]
        walker = SafeFunWalker()
        if node:
            walker.walk_safe_fun(node)
        return walker.modifications_after_call

    def extract_func_calls_definitions(self):
        ret = {}
        for contract in self.contracts["contractsById"]:
            name = self.contracts["contractsById"][contract]["name"]
            source = self.contracts["sourcesByContract"][contract]
            full_name = source + ":" + name
            ret[full_name] = self.extract_func_call_definitions(self.contracts["contractsById"][contract])
        return ret

    def extract_state_variable_names(self, c_name):
        state_variables = self.extract_states_definitions().get(c_name, [])
        var_names = []
        for var_name in state_variables:
            var_names.append(var_name["name"])
        return var_names

    def extract_func_call_srcs(self, c_name):
        func_calls = self.extract_func_calls_definitions().get(c_name, [])
        func_call_srcs = []
        for func_call in func_calls:
            # 获取函数名称
            func_name = None
            if "expression" in func_call:
                expression = func_call["expression"]
                if "memberName" in expression:
                    func_name = expression["memberName"]
                elif "name" in expression:
                    func_name = expression["name"]
                elif "expression" in expression:
                    sub_expression = expression["expression"]
                    if "memberName" in sub_expression:
                        func_name = sub_expression["memberName"]
                    elif "name" in sub_expression:
                        func_name = sub_expression["name"]

            if not func_name:
                func_name = "Unknown"

            func_call_srcs.append({
                "src": func_call["src"],
                "name": func_name
            })
        return func_call_srcs


    def get_callee_src(self, c_name):
        node = self.contracts["contractsByName"][c_name]
        walker = AstWalker()
        nodes = []
        if node:
            list_of_attributes = [
                {"memberName": "delegatecall"},
                {"memberName": "call"},
                {"memberName": "callcode"},
            ]
            walker.walk(node, list_of_attributes, nodes)
        callee_src = []
        for node in nodes:
            callee_info = {
                "function_name": None,
                 "src": node["src"]
            }
            # 尝试从expression中获取函数名
            if "expression" in node:
                expression = node["expression"]
                if "memberName" in expression:
                    callee_info["function_name"] = expression["memberName"]
                elif "name" in expression:
                    callee_info["function_name"] = expression["name"]
            # 如果expression中没有找到函数名，从children中获取
            if callee_info["function_name"] is None and "children" in node and len(node["children"]) > 1:
                if "attributes" in node["children"][1] and "memberName" in node["children"][1]["attributes"]:
                    callee_info["function_name"] = node["children"][1]["attributes"]["memberName"]

            if callee_info["function_name"] is None:
                callee_info["function_name"] = "Unknown"
            callee_src.append(callee_info)
        return callee_src

    def get_func_name_to_params(self, c_name):
        node = self.contracts["contractsByName"][c_name]
        walker = AstWalker()
        func_def_nodes = []
        if node:
            walker.walk(node, {"nodeType": "FunctionDefinition"}, func_def_nodes)
        func_name_to_params = {}
        for func_def_node in func_def_nodes:
            func_name = func_def_node["name"]
            params_nodes = []
            walker.walk(func_def_node, {"nodeType": "ParameterList"}, params_nodes)
            params_node = params_nodes[0]
            param_nodes = []
            walker.walk(params_node, {"nodeType": "VariableDeclaration"}, param_nodes)
            for param_node in param_nodes:
                var_name = param_node["name"]
                type_name = param_node["typeName"]["nodeType"]
                if type_name == "ArrayTypeName":
                    literal_nodes = []
                    walker.walk(param_node, {"nodeType": "Literal"}, literal_nodes)
                    if literal_nodes:
                        array_size = int(literal_nodes[0]["value"])
                    else:
                        array_size = 1
                    param = {"name": var_name, "type": type_name, "value": array_size}
                elif type_name == "ElementaryTypeName":
                    param = {"name": var_name, "type": type_name}
                else:
                    param = {"name": var_name, "type": type_name}
                if func_name not in func_name_to_params:
                    func_name_to_params[func_name] = [param]
                else:
                    func_name_to_params[func_name].append(param)
        return func_name_to_params

    def extract_contract_ast(self, contract_path: str):
        contract_details = {}
        file_name = os.path.basename(contract_path).replace('.sol', '')
        if not os.path.exists(contract_path):
            raise FileNotFoundError('Contract address file not found: ' + contract_path)
        try:
            with open(contract_path, 'r', encoding='utf-8') as f:
                code = re.sub(r"\n\s*\n", "\n", f.read())
            compiled_sol = compile_source(
                code,
                output_values=['ast'],
                allow_paths=".,./node_modules/@openzeppelin/"
            )
            ast = list(compiled_sol.values())[0]['ast']
            self.contracts = self.extract_contract_definitions({contract_path: {"ast": ast}})
            contract_code_list = self.extract_contract_code(ast, code)
            for contract_name in contract_code_list.keys():
                contract_node = self.contracts["contractsByName"][contract_path + ":" + contract_name]
                state_vars = self.extract_state_definitions(contract_node)
                func_calls = self.extract_func_call_definitions(contract_node)
                func_defs = self.extract_func_definitions(contract_node)
                safe_func_call_info = self.extract_safe_func_call_info(contract_path + ":" + contract_name)
                func_name_to_params = self.get_func_name_to_params(contract_path + ":" + contract_name)
                func_call_srcs = self.extract_func_call_srcs(contract_path + ":" + contract_name)
                callee_src = self.get_callee_src(contract_path + ":" + contract_name)
                contract_details = {
                    "name": contract_name,
                    "state_vars": [var["name"] for var in state_vars if "name" in var],
                    "func_calls": [call["expression"]["name"] for call in func_calls if "expression" in call and "name" in call["expression"]],
                    "func_defs": [func["name"] for func in func_defs if "name" in func],
                    "safe_func_call_info": safe_func_call_info,
                    "func_name_to_params": func_name_to_params,
                    "func_call_srcs": func_call_srcs,
                    "callee_src": callee_src
                }
        except Exception as e:
            logger.error(f"Error parsing contract path: {contract_path}")
            logger.error(f"Exception: {str(e)}")
            return
        if contract_details:
            with open(f'./data/AST_info/{file_name}.json', 'w') as f:
                json.dump(contract_details, f, indent=4)
        return contract_details

    def extract_contract_code(self, ast, code):
        contract_code_list = {}
        lines = code.split('\n')
        for contract in ast['nodes']:
            if contract['nodeType'] == 'ContractDefinition':
                contract_name = contract['name']
                start_line, _, length = map(int, contract['src'].split(':'))
                end_line = start_line + length
                contract_code = ''.join(lines[start_line:end_line])
                contract_code_list[contract_name] = contract_code
        return contract_code_list

def main(contract_path: str, output_path: str):
    parser = ContractParser(contract_path, ['./node_modules/@openzeppelin/contracts/'], "solidity")
    contract_details = parser.extract_contract_ast(contract_path)
    if contract_details:
        file_name = os.path.basename(contract_path).replace('.sol', '')
        output_file = os.path.join(output_path, f'{file_name}.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(contract_details, f, indent=4)
        print(f"AST for contract {contract_path} saved to {output_file}")
    else:
        print(f"Failed to generate AST for contract {contract_path}")


def run_command(cmd):
    FNULL = open(os.devnull, "w")
    logger.info(f"Running command: {cmd}")
    solc_p = subprocess.Popen(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = solc_p.communicate()
    out = out.decode("utf-8", "strict")
    err = err.decode("utf-8", "strict")

    # Write the full output to a log file instead of the console
    with open("command_output.log", "a") as log_file:
        log_file.write(f"Command: {cmd}\n")
        log_file.write(f"Output: {out}\n")
        if err:
            log_file.write(f"Error: {err}\n")
        log_file.write("\n")

    return out, err

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate AST for a given smart contract or a directory of smart contracts")
    parser.add_argument('--contract', type=str, help="Path to the smart contract")
    parser.add_argument('--directory', type=str, help="Directory containing multiple smart contract files")
    parser.add_argument('--output', type=str, required=True, help="Directory to save the output AST JSON files")

    args = parser.parse_args()

    if args.contract:
        main(args.contract, args.output)
    elif args.directory:
        contract_files = glob(os.path.join(args.directory, "*.sol"))
        for contract_file in contract_files:
            main(contract_file, args.output)
    else:
        print("Please provide a path to a smart contract file or a directory containing multiple smart contract files.")