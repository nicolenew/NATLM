class AstWalker:
    def walk(self, node, attributes, nodes):
        if isinstance(attributes, dict):
            self._walk_with_attrs(node, attributes, nodes)  # 根据属性字典遍历
        else:
            self._walk_with_list_of_attrs(node, attributes, nodes)  # 根据属性列表遍历

    def _walk_with_attrs(self, node, attributes, nodes):
        if self._check_attributes(node, attributes):
            nodes.append(node)  # 节点符合条件则添加到节点列表
        else:
            if isinstance(node, dict):
                for key in node:
                    if isinstance(node[key], list):
                        for child in node[key]:
                            self._walk_with_attrs(child, attributes, nodes)  # 递归遍历列表子节点
                    elif isinstance(node[key], dict):
                        self._walk_with_attrs(node[key], attributes, nodes)  # 递归遍历字典子节点
                    else:
                        continue
            elif isinstance(node, list):
                for key in node:
                    self._walk_with_attrs(node[key], attributes, nodes)  # 递归遍历列表节点

    def _walk_with_list_of_attrs(self, node, list_of_attributes, nodes):
        if self._check_list_of_attributes(node, list_of_attributes):
            nodes.append(node)  # 节点符合条件则添加到节点列表
        else:
            if isinstance(node, dict):
                for key in node:
                    if isinstance(node[key], list):
                        for child in node[key]:
                            self._walk_with_list_of_attrs(
                                child, list_of_attributes, nodes
                            )  # 递归遍历列表子节点
                    elif isinstance(node[key], dict):
                        self._walk_with_list_of_attrs(
                            node[key], list_of_attributes, nodes
                        )  # 递归遍历字典子节点
                    else:
                        continue
            elif isinstance(node, list):
                for key in node:
                    self._walk_with_list_of_attrs(node[key], list_of_attributes, nodes)  # 递归遍历列表节点

    def extract_event_definitions(self, node):
        walker = AstWalker()
        nodes = []
        if node:
            walker.walk(node, {"nodeType": "EventDefinition"}, nodes)

        return nodes

    def _check_attributes(self, node, attributes):
        if not isinstance(node, dict):
            return False
        for name in attributes:
            if name not in node or node[name] != attributes[name]:
                return False
        return True

    def _check_list_of_attributes(self, node, list_of_attributes):
        for attrs in list_of_attributes:
            if self._check_attributes(node, attrs):
                return True
        return False
